#!/bin/bash
apt-get update && apt-get install -y tesseract-ocr libtesseract-dev
python Bot_mcq0.4v.py
